import java.util.Scanner;

public class AccountTest {

    public static void main(String[] args) {
	// write your code here
        Scanner scanner = new Scanner(System.in);
        System.out.println("ENTER YOUR INCOME THIS MONTH: ");
        double balance = scanner.nextDouble();
        Account account = new Account(balance);
        account.necMethod(balance);
        account.ffaMethod(balance);
        account.eduMethod(balance);
        account.ltssMethod(balance);
        account.playMethod(balance);
        account.giveMethod(balance);
        System.out.println("NEC: " + account.getNec());
        System.out.println("FFA: " + account.getFfa());
        System.out.println("EDU: " + account.getEdu());
        System.out.println("LTSS: " + account.getLtss());
        System.out.println("PLAY: " + account.getPlay());
        System.out.println("GIVE: " + account.getGive());
    }
}
