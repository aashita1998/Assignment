public class Account {
    double nec;
    double ffa;
    double edu;
    double ltss;
    double play;
    double give;

    public Account(double balance) {
        if (balance > 0.0) {
            nec = balance;
            ffa = balance;
            edu = balance;
            ltss = balance;
            play = balance;
            give = balance;
        }
    }

    public void necMethod(double amount){
        nec = (55 * amount)/100;
    }
    public double getNec(){
        return nec;
    }

    public void ffaMethod(double amount){
        ffa = (10 * amount)/100;
    }
    public double getFfa(){
        return ffa;
    }

    public void eduMethod(double amount){
        edu = (10 * amount)/100;
    }
    public double getEdu(){
        return edu;
    }

    public void ltssMethod(double amount){
        ltss = (10 * amount)/100;
    }
    public double getLtss(){
        return ltss;
    }

    public void playMethod(double amount){
        play = (10 * amount)/100;
    }
    public double getPlay(){
        return play;
    }

    public void giveMethod(double amount){
        give = (5 * amount)/100;
    }
    public double getGive(){
        return give;
    }
}
