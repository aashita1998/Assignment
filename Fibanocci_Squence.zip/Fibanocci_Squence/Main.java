import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int n1 = 0;
        int n2 = 1;
        int sum=0;
        int n;
        Scanner scanner = new Scanner(System.in);
        System.out.println("N = ");
        n = scanner.nextInt();
        System.out.println(n2+"");
        while (sum <= n){
            sum = n1 + n2;
            if(sum >= n){
                break;
            }
            System.out.println(sum+"");
            n1 = n2;
            n2 = sum;
        }
    }
}
