import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int A[] = new int[2];
        Scanner scanner = new Scanner(System.in);
        System.out.println("Point A (x,y):");
        for (int i=0; i<2; i++){
            A[i] = scanner.nextInt();
        }

        int B[] = new int[2];
        System.out.println("Point B (x,y):");
        for (int i=0; i<2; i++){
            B[i] = scanner.nextInt();
        }

        int C[] = new int[2];
        System.out.println("Point C (x,y):");
        for (int i=0; i<2; i++){
            C[i] = scanner.nextInt();
        }
        double area = ((C[0] - A[0]) * (B[1] - A[1]))/2;
        System.out.println("Area = "+area);
    }
}