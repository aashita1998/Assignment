import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Scanner scanner = new Scanner(System.in);
        System.out.println("N= ");
        int number = scanner.nextInt();
        int factorial = 1;
        int counter = 1;
        while(counter <= number){
            factorial *= counter;
            counter++;
        }
        System.out.println(factorial);
    }
}
